library(testthat)
library(rhello)

test_check("rhello")
