library(testthat)
library(rhasdata)

test_check("rhasdata")
