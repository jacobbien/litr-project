# Generated from create-rhasdata.Rmd: do not edit by hand

#' A regression data set
#' 
#' @format A data frame with 100 rows and 2 variables:
#' \describe{
#' \item{x}{a predictor variable}
#' \item{y}{a response variable}
#' @source This data was simulated.  But usually we might cite a source here.
"mydata"
