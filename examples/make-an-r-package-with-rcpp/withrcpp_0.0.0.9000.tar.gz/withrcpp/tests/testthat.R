library(testthat)
library(withrcpp)

test_check("withrcpp")
