#' My great package
#'
#' Here's an overview of the package.
#' 
#' @docType package
#' @seealso \code{\link{alternate_signs}}
#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom Rcpp sourceCpp
#' @useDynLib withrcpp, .registration = TRUE
## usethis namespace: end
NULL
